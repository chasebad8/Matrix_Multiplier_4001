#ifndef MATRIX_DEF_H
#define MATRIX_DEF_H
#endif

struct matrix_struct {
	int Q[4][4];
	int M[4][4];
	int N[4][4];
	int largestNum[4];
};